# Land Fraud Detection v2

This version includes Streamlit integration and a sample dataset.
Run with:
```
streamlit run land_fraud_pipeline_notebook.py
```