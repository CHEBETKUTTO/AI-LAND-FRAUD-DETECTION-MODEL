import pandas as pd
import numpy as np
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import shap
import matplotlib.pyplot as plt
import joblib
import os

st.set_page_config(page_title="Land Fraud Detection AI", layout="wide")
st.title("🏠 AI Model for Land Fraud Detection")
st.write("This AI model detects potential land fraud by analyzing ownership patterns, disputes, and registry data.")

default_path = "sample_land_records.csv"
if os.path.exists(default_path):
    df = pd.read_csv(default_path)
    st.success("✅ Sample dataset loaded successfully!")
else:
    st.warning("⚠️ sample_land_records.csv not found. Please upload your own dataset.")

uploaded_file = st.file_uploader("Upload your land records CSV (optional):", type=["csv"])
if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.success("✅ Custom dataset loaded!")

st.subheader("📋 Dataset Preview")
st.dataframe(df.head())

if 'fraudulent' in df.columns:
    X = df.drop(columns=['fraudulent', 'owner_name', 'title_deed_number', 'registrar_name'], errors='ignore')
    y = df['fraudulent']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

    model = RandomForestClassifier(n_estimators=150, random_state=42)
    model.fit(X_train, y_train)

    joblib.dump(model, "land_fraud_model.pkl")

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    st.subheader("📊 Model Performance")
    st.write(f"Accuracy: **{acc:.2f}**")
    st.text(classification_report(y_test, y_pred))

    st.subheader("🔍 Model Explainability (SHAP Values)")
    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_train)
    fig, ax = plt.subplots()
    shap.summary_plot(shap_values[1], X_train, show=False)
    st.pyplot(fig)
else:
    st.error("❌ The dataset must include a 'fraudulent' column (0 = Legit, 1 = Fraudulent).")

st.subheader("🤖 Try Predicting a New Land Record")

with st.form("prediction_form"):
    ownership_years = st.number_input("Ownership Years", 0, 100, 5)
    disputes_reported = st.number_input("Disputes Reported", 0, 10, 0)
    valuation_mismatch = st.selectbox("Valuation Mismatch", [0, 1])
    multiple_owners_flag = st.selectbox("Multiple Owners Flag", [0, 1])
    succession_issues_flag = st.selectbox("Succession Issues Flag", [0, 1])
    predict_btn = st.form_submit_button("Predict Fraud Risk")

if predict_btn:
    model = joblib.load("land_fraud_model.pkl")
    input_data = pd.DataFrame([
        [ownership_years, disputes_reported, valuation_mismatch, multiple_owners_flag, succession_issues_flag]
    ], columns=['ownership_years', 'disputes_reported', 'valuation_mismatch', 'multiple_owners_flag', 'succession_issues_flag'])
    prediction = model.predict(input_data)[0]
    result = "⚠️ Potential Fraud Detected!" if prediction == 1 else "✅ Likely Legitimate Land Record"
    st.success(result)
